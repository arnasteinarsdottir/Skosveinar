

import Navbar from "../Components/Navbar.tsx";
import SearchGifts from "../Components/SearchGifts.tsx";

function Leita() {
    return (
        <>  
        <Navbar/>
        <SearchGifts/>
        </>
    );
    }
    export default Leita;