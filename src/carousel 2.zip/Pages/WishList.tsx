import Navbar from "../Components/Navbar.tsx";
import ChildGiftViewer from "../Components/ChildGiftViewer.tsx";

function WishList() {
    return (
        <>  
        <Navbar/>
        <ChildGiftViewer/>
        </>
    );
    }
    export default WishList;