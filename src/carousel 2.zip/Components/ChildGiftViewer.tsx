import { useState, useEffect } from "react";
import type { Product } from "./SearchGifts";

export default function ChildGiftViewer() {
  const [childNames, setChildNames] = useState<string[]>([]);
  const [selectedChild, setSelectedChild] = useState<string | null>(null);
  const [childProducts, setChildProducts] = useState<Product[]>([]);

  // ✅ Функция получения подарков для ребёнка
  const getGiftsForChild = (childName: string): Product[] => {
    const saved = localStorage.getItem("ChildrensCards");
    if (!saved) return [];

    try {
      const parsed: Record<string, Product[]> = JSON.parse(saved);
      return parsed[childName] || [];
    } catch (err) {
      console.error("Ошибка при чтении подарков:", err);
      return [];
    }
  };

  useEffect(() => {
    const loadChildren = () => {
      const saved = localStorage.getItem("ChildrensCards");
      if (!saved) return;

      try {
        const parsed: Record<string, Product[]> = JSON.parse(saved);
        setChildNames(Object.keys(parsed));
      } catch (err) {
        console.error("Ошибка при чтении ChildrensCards:", err);
      }
    };

    loadChildren();
  }, []);

  const handleSelect = (name: string) => {
    setSelectedChild(name);
    setChildProducts(getGiftsForChild(name)); // ✅ используем новую функцию
  };

  return (
    <div className="w-full max-w-[400px] mx-auto mt-6 space-y-4">
      {/* Dropdown menu */}
      <select
        className="w-full p-2 border border-darkgreen rounded font-quicksand"
        value={selectedChild || ""}
        onChange={(e) => handleSelect(e.target.value)}
      >
        <option value="" disabled>
          Veldu barn
        </option>
        {childNames.map((name) => (
          <option key={name} value={name}>
            {name}
          </option>
        ))}
      </select>

      {/* Product list */}
      {selectedChild && (
        <div className="space-y-3">
          <h4 className="text-darkgreen font-bold font-quicksand">
            Gjafir fyrir: {selectedChild}
          </h4>
          {childProducts.length === 0 ? (
            <p className="text-sm text-gray-500">Engar gjafir skráðar.</p>
          ) : (
            childProducts.map((product, index) => (
              <div
                key={index}
                className="border border-darkgreen rounded p-3 bg-[#EEE2D2]"
              >
                <h5 className="font-bold text-sm">{product.title}</h5>
                <p className="text-xs text-darkred">{product.price} kr</p>
                <a
                  href={product.link}
                  className="text-xs text-darkgreen underline"
                >
                  {product.store}
                </a>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}